<?php
$MESS['ITRACK_RDMC_FILTER_PRESET_CC_NAME'] = 'Общее';
$MESS['ITRACK_RDMC_COLUMN_AUTHOR_NAME'] = 'Ответственный менеджер';
$MESS['ITRACK_RDMC_COLUMN_INTERVAL_NAME'] = 'Период';
$MESS['ITRACK_RDMC_COLUMN_CATEGORY_NAME'] = 'Направление';
$MESS['ITRACK_RDMC_COLUMN_NOT_SHOW_NULL_NAME'] = 'Не отображать воронки с отсутствием перемещений';
$MESS['ITRACK_RDMC_NO'] = 'Нет';
$MESS['ITRACK_RDMC_YES'] = 'Да';