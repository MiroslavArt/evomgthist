<?php
require_once ($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
?>

<?php
require_once ($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');